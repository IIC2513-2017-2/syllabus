// images es un arreglo de objetos con datos de imagenes

var image = null;
var imageObjs = [];
for (var i = 1, len = 2; i < len; i++) {
  image = images[i];
  console.log(image);
  imageObjs[i] = new Image();
  
  imageObjs[i].onload = (function(image, imageObj) {
    return function() {
    var kimage = new Kinetic.Image({
      x: image.x,
      y: image.y,
      image: imageObj
    });
    layer.add(kimage);
  };
  })(image, imageObjs[i]);
  
  
  
  imageObjs[i].src = '/vsm/images/' + image.path;
}