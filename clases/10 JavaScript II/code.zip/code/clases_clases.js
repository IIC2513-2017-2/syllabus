class Mamifero {
  constructor(name) {
    this.getName = function() {
      return name;
    };

    this.setName = function(theName) {
      name = theName;
    };
  }
  
  habla() {
    console.log('...' + this.getName());
  }
}

class Perro extends Mamifero {
  constructor(name) {
    super(name);
  }
  
  habla() {
    console.log(this.getName() + ': guau!');
  }
}

const perro = new Perro('Snoopy');
perro.getName();
perro.habla();
perro.setName('Pluto');
perro.habla();

const nuevoMamifero = new Mamifero('una jirafa');
nuevoMamifero.habla();
