// primera parte
let v1 = 1;

function f1(p1) {
  let v1 = p1 + 1;
  return v1;
}

console.log(f1(2));
console.log(v1);


console.log('\n\n\n');



// segunda parte
let i;
let v2 = 3;
let funcs = [];
for (i = 0; i < v2; i += 1) {
  funcs.push(function() {
    console.log(i);
  });
}

for (let j = 0; j < v2; j += 1) {
  funcs[j]();
}


console.log('\n\n\n');


// tercera parte
function f2(p1, func) {
  let v3 = v2;
  let f3 = function() {
    v3 = v3 - p1;
    console.log(v3);
    console.log(func(v3));
  };
  return f3;
}

let f4 = f2(1, f1);
v2 += 1;
let f5 = f2(2, f1);
f4();
f5();
f4();
f5();
