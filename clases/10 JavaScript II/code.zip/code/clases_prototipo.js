function Mamifero(name) {
  this.getName = function() {
    return name;
  };

  this.setName = function(theName) {
    name = theName;
  };
}

Mamifero.prototype.habla = function() {
  console.log('...' + this.getName());
};

function Perro(name) {
  Mamifero.call(this, name);
}

Perro.prototype = Object.create(Mamifero.prototype);

Perro.prototype.habla = function() {
  console.log(this.getName() + ': guau!');
};

const perro = new Perro('Snoopy');
perro.getName();
perro.habla();
perro.setName('Pluto');
perro.habla();

const nuevoMamifero = new Mamifero('una jirafa');
nuevoMamifero.habla();
