// images es un arreglo de objetos con datos de imagenes

var image = null;
var imageObjs = [];
for (var i = 1; i < images.length; i++) {
  image = images[i];
  console.log(image);
  imageObjs[i] = new Image();
  
  imageObjs[i].onload = function() {
    var kimage = new Kinetic.Image({
      x: image.x,
      y: image.y,
      image: imageObj
    });
    layer.add(kimage);
  };
  imageObjs[i].src = '/vsm/images/' + image.path;
}